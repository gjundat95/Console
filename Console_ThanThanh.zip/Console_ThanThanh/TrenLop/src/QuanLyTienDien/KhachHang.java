package QuanLyTienDien;

public class KhachHang 
{
	public String maKhach;
	public String tenKhach;
	public String diaChi;
	
}
